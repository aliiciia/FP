// http://api.twitter.com/1/statuses/user_timeline/codeinfused.json

$(document).ready(function(){

    var loadTweets = function(){
        $.ajax({
              url: "http://codeinfused.com/api/gettwitter.php?user=TheMegaMindz",
              type: "get",
              dataType: "jsonp",
              success: function(r){   
                var html = $.render(r.feed, 'twitter');
                $(html).appendTo('#feed');
                
              }
       });  
    };
    
    $.fetcher('templates/twitter.html', loadTweets);

});